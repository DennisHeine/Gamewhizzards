﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Data;
namespace WorldEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         
        }

        public void selectItem()
        {
            String name = lbItems.SelectedItem.ToString();
            Item item = loadItemFromName(name);
            txtItemUIImage.Text = item.UIImage;
            txtItemMaxLevel.Text = item.MaxLevel.ToString();
            txtItemsMinLevel.Text = item.MinLevel.ToString();
            txtItemMesh.Text = item.MeshNameAndPath;
        }

        public void loadItems()
        {
            Width = grpSpells.Right + 25;
            Height = grpResources.Bottom + 75;
            foreach (Item item in WorldState.worldState.Items.Values)
            {
                lbItems.Items.Add(item.Name);
            }
        }

        public void saveItem()
        {
            String name = lbItems.SelectedItem.ToString();
            Item item = loadItemFromName(name);
            item.MaxLevel = int.Parse(txtItemMaxLevel.Text);
            item.MinLevel = int.Parse(txtItemsMinLevel.Text);
            item.MeshNameAndPath = txtItemMesh.Text;
            item.UIImage = txtItemUIImage.Text;
            ReplaceItem(item.Name, item);
        }

        private void ReplaceItem(object itemName, Item item)
        {
            bool found = false;
            foreach (Item itm in WorldState.worldState.Items.Values)
            {
                if (itm.Name == (String)itemName)
                {
                    found = true;
                    WorldState.worldState.Items[itm.Name] = item;
                }
            }
            if (!found)
                WorldState.worldState.Items.Add(item.Name, item);

        }

        private Item loadItemFromName(string name)
        {
            foreach(Item itm in WorldState.worldState.Items.Values)
            {
                if (itm.Name == name)
                    return itm;
            }
            return new Item();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            grpStats.Visible = true;
            grpStats.Left = ((Button)sender).Left;
            grpStats.Top = ((Button)sender).Bottom;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            grpStats.Visible = true;
            grpStats.Left = ((Button)sender).Left;
            grpStats.Top = ((Button)sender).Bottom;

        }

        private void button10_Click(object sender, EventArgs e)
        {
            grpStats.Visible = true;
            grpStats.Left = ((Button)sender).Left;
            grpStats.Top = ((Button)sender).Bottom;

        }

        private void button32_Click(object sender, EventArgs e)
        {
            grpStats.Visible = false;
        }

        private void button12_Click(object sender, EventArgs e)
        {

            grpSpellRotation.Visible = true;
            grpSpellRotation.Left = ((Button)sender).Left;
            grpSpellRotation.Top = ((Button)sender).Bottom;
        }

        private void button36_Click(object sender, EventArgs e)
        {
            grpDialogs.Visible = false;
        }

        private void button35_Click(object sender, EventArgs e)
        {
            grpLoot.Visible = false;
        }

        private void button34_Click(object sender, EventArgs e)
        {
            grpSpellRotation.Visible = false;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        
        }

        
    }
}
