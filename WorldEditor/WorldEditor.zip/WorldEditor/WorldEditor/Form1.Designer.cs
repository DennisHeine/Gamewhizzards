﻿namespace WorldEditor
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbItems = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtItemUIImage = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtItemMesh = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtItemsMinLevel = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.txtItemMaxLevel = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bnItemsStats = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.grpSpells = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.grpStats = new System.Windows.Forms.GroupBox();
            this.button32 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Value = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.grpLoot = new System.Windows.Forms.GroupBox();
            this.button35 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.listBox8 = new System.Windows.Forms.ListBox();
            this.grpSpellRotation = new System.Windows.Forms.GroupBox();
            this.button34 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.label25 = new System.Windows.Forms.Label();
            this.grpDialogs = new System.Windows.Forms.GroupBox();
            this.button36 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.button19 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.grpResources = new System.Windows.Forms.GroupBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.worldSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.grpSpells.SuspendLayout();
            this.grpStats.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            this.grpLoot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.grpSpellRotation.SuspendLayout();
            this.grpDialogs.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.grpResources.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbItems
            // 
            this.lbItems.FormattingEnabled = true;
            this.lbItems.Location = new System.Drawing.Point(6, 37);
            this.lbItems.Name = "lbItems";
            this.lbItems.Size = new System.Drawing.Size(120, 95);
            this.lbItems.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Items";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(156, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "UI Image";
            // 
            // txtItemUIImage
            // 
            this.txtItemUIImage.Location = new System.Drawing.Point(159, 37);
            this.txtItemUIImage.Name = "txtItemUIImage";
            this.txtItemUIImage.Size = new System.Drawing.Size(121, 20);
            this.txtItemUIImage.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(157, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "MeshNameAndPath";
            // 
            // txtItemMesh
            // 
            this.txtItemMesh.Location = new System.Drawing.Point(160, 76);
            this.txtItemMesh.Name = "txtItemMesh";
            this.txtItemMesh.Size = new System.Drawing.Size(120, 20);
            this.txtItemMesh.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(157, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Type";
            // 
            // cbType
            // 
            this.cbType.FormattingEnabled = true;
            this.cbType.Items.AddRange(new object[] {
            "ITM_WEAPON",
            "ITM_ARMOR",
            "ITM_CONSUMABLE",
            "ITM_MAGICAL"});
            this.cbType.Location = new System.Drawing.Point(159, 111);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(121, 21);
            this.cbType.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(297, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "MinLevel";
            // 
            // txtItemsMinLevel
            // 
            this.txtItemsMinLevel.Location = new System.Drawing.Point(300, 36);
            this.txtItemsMinLevel.Name = "txtItemsMinLevel";
            this.txtItemsMinLevel.Size = new System.Drawing.Size(124, 20);
            this.txtItemsMinLevel.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(300, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "MaxLevel";
            // 
            // txtItemMaxLevel
            // 
            this.txtItemMaxLevel.Location = new System.Drawing.Point(303, 80);
            this.txtItemMaxLevel.Name = "txtItemMaxLevel";
            this.txtItemMaxLevel.Size = new System.Drawing.Size(121, 20);
            this.txtItemMaxLevel.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(300, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Stats";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bnItemsStats);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.lbItems);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtItemMaxLevel);
            this.groupBox1.Controls.Add(this.txtItemUIImage);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtItemsMinLevel);
            this.groupBox1.Controls.Add(this.txtItemMesh);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbType);
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(433, 174);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Items";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // bnItemsStats
            // 
            this.bnItemsStats.Location = new System.Drawing.Point(300, 111);
            this.bnItemsStats.Name = "bnItemsStats";
            this.bnItemsStats.Size = new System.Drawing.Size(124, 21);
            this.bnItemsStats.TabIndex = 17;
            this.bnItemsStats.Text = "...";
            this.bnItemsStats.UseVisualStyleBackColor = true;
            this.bnItemsStats.Click += new System.EventHandler(this.button8_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(349, 145);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 16;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(267, 144);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(186, 144);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grpSpells
            // 
            this.grpSpells.Controls.Add(this.button9);
            this.grpSpells.Controls.Add(this.button4);
            this.grpSpells.Controls.Add(this.button5);
            this.grpSpells.Controls.Add(this.button6);
            this.grpSpells.Controls.Add(this.listBox2);
            this.grpSpells.Controls.Add(this.label8);
            this.grpSpells.Controls.Add(this.label9);
            this.grpSpells.Controls.Add(this.label10);
            this.grpSpells.Controls.Add(this.textBox5);
            this.grpSpells.Controls.Add(this.textBox6);
            this.grpSpells.Controls.Add(this.label11);
            this.grpSpells.Controls.Add(this.label12);
            this.grpSpells.Controls.Add(this.textBox7);
            this.grpSpells.Controls.Add(this.textBox8);
            this.grpSpells.Controls.Add(this.label13);
            this.grpSpells.Controls.Add(this.label14);
            this.grpSpells.Controls.Add(this.comboBox4);
            this.grpSpells.Location = new System.Drawing.Point(452, 33);
            this.grpSpells.Name = "grpSpells";
            this.grpSpells.Size = new System.Drawing.Size(433, 174);
            this.grpSpells.TabIndex = 17;
            this.grpSpells.TabStop = false;
            this.grpSpells.Text = "Spells";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(300, 111);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(124, 21);
            this.button9.TabIndex = 18;
            this.button9.Text = "...";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(349, 145);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 16;
            this.button4.Text = "Delete";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(267, 144);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 15;
            this.button5.Text = "Save";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(186, 144);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 14;
            this.button6.Text = "Add";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(6, 37);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 95);
            this.listBox2.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Spells";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(300, 99);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Stats";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(156, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Name ";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(303, 80);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(121, 20);
            this.textBox5.TabIndex = 11;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(159, 37);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(121, 20);
            this.textBox6.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(300, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "AnimationName";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(157, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Description ";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(300, 36);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(124, 20);
            this.textBox7.TabIndex = 9;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(160, 76);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(120, 20);
            this.textBox8.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(297, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "SpellLevel";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(157, 99);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Type";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(159, 111);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 7;
            // 
            // grpStats
            // 
            this.grpStats.Controls.Add(this.button32);
            this.grpStats.Controls.Add(this.groupBox5);
            this.grpStats.Controls.Add(this.button7);
            this.grpStats.Controls.Add(this.textBox10);
            this.grpStats.Controls.Add(this.label16);
            this.grpStats.Controls.Add(this.listView1);
            this.grpStats.Location = new System.Drawing.Point(1029, 33);
            this.grpStats.Name = "grpStats";
            this.grpStats.Size = new System.Drawing.Size(255, 168);
            this.grpStats.TabIndex = 18;
            this.grpStats.TabStop = false;
            this.grpStats.Text = "Stats";
            this.grpStats.Visible = false;
            // 
            // button32
            // 
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(234, 14);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(15, 20);
            this.button32.TabIndex = 25;
            this.button32.Text = "x";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(0, 174);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(255, 100);
            this.groupBox5.TabIndex = 20;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "groupBox5";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(137, 80);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 24;
            this.button7.Text = "Save";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(128, 37);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 20);
            this.textBox10.TabIndex = 23;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(125, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 13);
            this.label16.TabIndex = 22;
            this.label16.Text = "Value";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Name,
            this.Value});
            this.listView1.Location = new System.Drawing.Point(6, 19);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(116, 97);
            this.listView1.TabIndex = 19;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // Name
            // 
            this.Name.Text = "Name";
            // 
            // Value
            // 
            this.Value.Text = "Value";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button13);
            this.groupBox4.Controls.Add(this.button14);
            this.groupBox4.Controls.Add(this.button15);
            this.groupBox4.Controls.Add(this.textBox14);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.button12);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.button11);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.textBox9);
            this.groupBox4.Controls.Add(this.textBox11);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.textBox12);
            this.groupBox4.Controls.Add(this.textBox13);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.comboBox2);
            this.groupBox4.Controls.Add(this.listBox3);
            this.groupBox4.Location = new System.Drawing.Point(18, 207);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(571, 190);
            this.groupBox4.TabIndex = 19;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Characters";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(341, 147);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 38;
            this.button13.Text = "Delete";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(259, 146);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 37;
            this.button14.Text = "Save";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(178, 146);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 36;
            this.button15.Text = "Add";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(276, 111);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(124, 20);
            this.textBox14.TabIndex = 35;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(276, 98);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 13);
            this.label24.TabIndex = 34;
            this.label24.Text = "Name";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(433, 79);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(124, 21);
            this.button12.TabIndex = 33;
            this.button12.Text = "...";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(430, 62);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 13);
            this.label23.TabIndex = 33;
            this.label23.Text = "SpellRotation";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(433, 34);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(124, 21);
            this.button11.TabIndex = 32;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(430, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(28, 13);
            this.label17.TabIndex = 31;
            this.label17.Text = "Loot";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(133, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(102, 13);
            this.label22.TabIndex = 30;
            this.label22.Text = "MeshNameAndPath";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(433, 110);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(124, 21);
            this.button10.TabIndex = 29;
            this.button10.Text = "...";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(436, 98);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(31, 13);
            this.label15.TabIndex = 28;
            this.label15.Text = "Stats";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(279, 79);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(121, 20);
            this.textBox9.TabIndex = 27;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(135, 36);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(121, 20);
            this.textBox11.TabIndex = 19;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(276, 62);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 13);
            this.label18.TabIndex = 26;
            this.label18.Text = "MaxLevel";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(133, 59);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(50, 13);
            this.label19.TabIndex = 20;
            this.label19.Text = "UI Image";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(276, 35);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(124, 20);
            this.textBox12.TabIndex = 25;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(136, 75);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(120, 20);
            this.textBox13.TabIndex = 21;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(273, 19);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(50, 13);
            this.label20.TabIndex = 24;
            this.label20.Text = "MinLevel";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(133, 98);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(31, 13);
            this.label21.TabIndex = 22;
            this.label21.Text = "Type";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(135, 110);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 23;
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(6, 19);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(120, 121);
            this.listBox3.TabIndex = 0;
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // grpLoot
            // 
            this.grpLoot.Controls.Add(this.button35);
            this.grpLoot.Controls.Add(this.button31);
            this.grpLoot.Controls.Add(this.numericUpDown1);
            this.grpLoot.Controls.Add(this.label35);
            this.grpLoot.Controls.Add(this.label34);
            this.grpLoot.Controls.Add(this.button30);
            this.grpLoot.Controls.Add(this.button33);
            this.grpLoot.Controls.Add(this.comboBox6);
            this.grpLoot.Controls.Add(this.listBox8);
            this.grpLoot.Location = new System.Drawing.Point(1016, 417);
            this.grpLoot.Name = "grpLoot";
            this.grpLoot.Size = new System.Drawing.Size(268, 171);
            this.grpLoot.TabIndex = 20;
            this.grpLoot.TabStop = false;
            this.grpLoot.Text = "Loot";
            this.grpLoot.Visible = false;
            // 
            // button35
            // 
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(253, 10);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(15, 20);
            this.button35.TabIndex = 48;
            this.button35.Text = "x";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(196, 67);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(47, 23);
            this.button31.TabIndex = 47;
            this.button31.Text = "Save";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(196, 37);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(55, 20);
            this.numericUpDown1.TabIndex = 46;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(188, 19);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 13);
            this.label35.TabIndex = 45;
            this.label35.Text = "Probabilty%";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 19);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(32, 13);
            this.label34.TabIndex = 34;
            this.label34.Text = "Items";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(163, 146);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(24, 23);
            this.button30.TabIndex = 44;
            this.button30.Text = "-";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(133, 146);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(24, 23);
            this.button33.TabIndex = 41;
            this.button33.Text = "+";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(6, 146);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(121, 21);
            this.comboBox6.TabIndex = 40;
            // 
            // listBox8
            // 
            this.listBox8.FormattingEnabled = true;
            this.listBox8.Location = new System.Drawing.Point(9, 31);
            this.listBox8.Name = "listBox8";
            this.listBox8.Size = new System.Drawing.Size(181, 108);
            this.listBox8.TabIndex = 39;
            // 
            // grpSpellRotation
            // 
            this.grpSpellRotation.Controls.Add(this.button34);
            this.grpSpellRotation.Controls.Add(this.button29);
            this.grpSpellRotation.Controls.Add(this.textBox21);
            this.grpSpellRotation.Controls.Add(this.label33);
            this.grpSpellRotation.Controls.Add(this.textBox20);
            this.grpSpellRotation.Controls.Add(this.label29);
            this.grpSpellRotation.Controls.Add(this.textBox19);
            this.grpSpellRotation.Controls.Add(this.label26);
            this.grpSpellRotation.Controls.Add(this.button28);
            this.grpSpellRotation.Controls.Add(this.button27);
            this.grpSpellRotation.Controls.Add(this.button26);
            this.grpSpellRotation.Controls.Add(this.button25);
            this.grpSpellRotation.Controls.Add(this.comboBox5);
            this.grpSpellRotation.Controls.Add(this.listBox7);
            this.grpSpellRotation.Controls.Add(this.label25);
            this.grpSpellRotation.Location = new System.Drawing.Point(1016, 207);
            this.grpSpellRotation.Name = "grpSpellRotation";
            this.grpSpellRotation.Size = new System.Drawing.Size(466, 190);
            this.grpSpellRotation.TabIndex = 21;
            this.grpSpellRotation.TabStop = false;
            this.grpSpellRotation.Text = "Spell Rotation";
            this.grpSpellRotation.Visible = false;
            // 
            // button34
            // 
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(451, 9);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(15, 20);
            this.button34.TabIndex = 46;
            this.button34.Text = "x";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(372, 161);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 23);
            this.button29.TabIndex = 45;
            this.button29.Text = "Save";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(213, 126);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(124, 20);
            this.textBox21.TabIndex = 44;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(210, 110);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(132, 13);
            this.label33.TabIndex = 43;
            this.label33.Text = "Weight (probability to cast)";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(210, 78);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(124, 20);
            this.textBox20.TabIndex = 42;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(202, 62);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(221, 13);
            this.label29.TabIndex = 41;
            this.label29.Text = "Cast only in phase no. (0 or empty for allways)";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(210, 32);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(124, 20);
            this.textBox19.TabIndex = 40;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(202, 16);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(245, 13);
            this.label26.TabIndex = 39;
            this.label26.Text = "Cast every n minutes (0 or empty to cast ramdomly)";
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(174, 117);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(24, 23);
            this.button28.TabIndex = 38;
            this.button28.Text = "-";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(174, 79);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(24, 23);
            this.button27.TabIndex = 37;
            this.button27.Text = "v";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(174, 52);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(24, 23);
            this.button26.TabIndex = 36;
            this.button26.Text = "^";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(143, 163);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(24, 23);
            this.button25.TabIndex = 35;
            this.button25.Text = "+";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(16, 163);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 21);
            this.comboBox5.TabIndex = 34;
            // 
            // listBox7
            // 
            this.listBox7.FormattingEnabled = true;
            this.listBox7.Location = new System.Drawing.Point(16, 36);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(152, 121);
            this.listBox7.TabIndex = 33;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(12, 20);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 13);
            this.label25.TabIndex = 32;
            this.label25.Text = "Spells";
            // 
            // grpDialogs
            // 
            this.grpDialogs.Controls.Add(this.button36);
            this.grpDialogs.Controls.Add(this.textBox18);
            this.grpDialogs.Controls.Add(this.button19);
            this.grpDialogs.Controls.Add(this.button23);
            this.grpDialogs.Controls.Add(this.button24);
            this.grpDialogs.Controls.Add(this.listBox6);
            this.grpDialogs.Controls.Add(this.label28);
            this.grpDialogs.Controls.Add(this.textBox15);
            this.grpDialogs.Controls.Add(this.label32);
            this.grpDialogs.Location = new System.Drawing.Point(1315, 427);
            this.grpDialogs.Name = "grpDialogs";
            this.grpDialogs.Size = new System.Drawing.Size(325, 171);
            this.grpDialogs.TabIndex = 22;
            this.grpDialogs.TabStop = false;
            this.grpDialogs.Text = "Dialogs";
            this.grpDialogs.Visible = false;
            // 
            // button36
            // 
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Location = new System.Drawing.Point(304, 10);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(15, 20);
            this.button36.TabIndex = 46;
            this.button36.Text = "x";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(161, 68);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(150, 62);
            this.textBox18.TabIndex = 45;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(244, 137);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(42, 23);
            this.button19.TabIndex = 44;
            this.button19.Text = "Del";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(198, 137);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(51, 23);
            this.button23.TabIndex = 43;
            this.button23.Text = "Save";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(161, 137);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(41, 23);
            this.button24.TabIndex = 42;
            this.button24.Text = "Add";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // listBox6
            // 
            this.listBox6.FormattingEnabled = true;
            this.listBox6.Location = new System.Drawing.Point(15, 19);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(120, 147);
            this.listBox6.TabIndex = 34;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(156, 14);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(18, 13);
            this.label28.TabIndex = 36;
            this.label28.Text = "ID";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(159, 31);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(152, 20);
            this.textBox15.TabIndex = 37;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(157, 53);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(61, 13);
            this.label32.TabIndex = 38;
            this.label32.Text = "Dialog Text";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button18);
            this.groupBox9.Controls.Add(this.button16);
            this.groupBox9.Controls.Add(this.button17);
            this.groupBox9.Controls.Add(this.listBox4);
            this.groupBox9.Location = new System.Drawing.Point(595, 216);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(290, 181);
            this.groupBox9.TabIndex = 23;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Quests";
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(137, 97);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(31, 23);
            this.button18.TabIndex = 14;
            this.button18.Text = "...";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(137, 39);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(31, 23);
            this.button16.TabIndex = 12;
            this.button16.Text = "+";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(137, 68);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(31, 23);
            this.button17.TabIndex = 13;
            this.button17.Text = "-";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            this.listBox4.Location = new System.Drawing.Point(10, 19);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(120, 134);
            this.listBox4.TabIndex = 1;
            // 
            // grpResources
            // 
            this.grpResources.Controls.Add(this.button20);
            this.grpResources.Controls.Add(this.button21);
            this.grpResources.Controls.Add(this.button22);
            this.grpResources.Controls.Add(this.listBox5);
            this.grpResources.Controls.Add(this.label27);
            this.grpResources.Controls.Add(this.textBox16);
            this.grpResources.Controls.Add(this.textBox17);
            this.grpResources.Controls.Add(this.label30);
            this.grpResources.Controls.Add(this.label31);
            this.grpResources.Controls.Add(this.comboBox3);
            this.grpResources.Location = new System.Drawing.Point(24, 400);
            this.grpResources.Name = "grpResources";
            this.grpResources.Size = new System.Drawing.Size(314, 171);
            this.grpResources.TabIndex = 24;
            this.grpResources.TabStop = false;
            this.grpResources.Text = "Resources";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(244, 142);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(42, 23);
            this.button20.TabIndex = 33;
            this.button20.Text = "Del";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(198, 142);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(51, 23);
            this.button21.TabIndex = 32;
            this.button21.Text = "Save";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(161, 142);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(41, 23);
            this.button22.TabIndex = 31;
            this.button22.Text = "Add";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            this.listBox5.Location = new System.Drawing.Point(15, 19);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(120, 134);
            this.listBox5.TabIndex = 18;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(156, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(18, 13);
            this.label27.TabIndex = 20;
            this.label27.Text = "ID";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(159, 36);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(127, 20);
            this.textBox16.TabIndex = 21;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(160, 110);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(126, 20);
            this.textBox17.TabIndex = 27;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(157, 94);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(23, 13);
            this.label30.TabIndex = 26;
            this.label30.Text = "File";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(157, 58);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(31, 13);
            this.label31.TabIndex = 24;
            this.label31.Text = "Type";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(159, 70);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(127, 21);
            this.comboBox3.TabIndex = 25;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1578, 24);
            this.menuStrip1.TabIndex = 25;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.loadToolStripMenuItem.Text = "Load...";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.saveToolStripMenuItem.Text = "Save...";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(106, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.worldSettingsToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // worldSettingsToolStripMenuItem
            // 
            this.worldSettingsToolStripMenuItem.Name = "worldSettingsToolStripMenuItem";
            this.worldSettingsToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.worldSettingsToolStripMenuItem.Text = "World Settings";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1578, 741);
            this.Controls.Add(this.grpDialogs);
            this.Controls.Add(this.grpSpellRotation);
            this.Controls.Add(this.grpLoot);
            this.Controls.Add(this.grpStats);
            this.Controls.Add(this.grpResources);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.grpSpells);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = new System.Windows.Forms.ColumnHeader("Form1");
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpSpells.ResumeLayout(false);
            this.grpSpells.PerformLayout();
            this.grpStats.ResumeLayout(false);
            this.grpStats.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            this.grpLoot.ResumeLayout(false);
            this.grpLoot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.grpSpellRotation.ResumeLayout(false);
            this.grpSpellRotation.PerformLayout();
            this.grpDialogs.ResumeLayout(false);
            this.grpDialogs.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.grpResources.ResumeLayout(false);
            this.grpResources.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbItems;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtItemUIImage;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtItemMesh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtItemsMinLevel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.TextBox txtItemMaxLevel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bnItemsStats;
        private System.Windows.Forms.GroupBox grpSpells;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.GroupBox grpStats;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Name;
        private System.Windows.Forms.ColumnHeader Value;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Diagnostics.EventLog eventLog1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox grpSpellRotation;
        private System.Windows.Forms.GroupBox grpLoot;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox grpResources;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox grpDialogs;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ListBox listBox8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem worldSettingsToolStripMenuItem;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
    }
}

